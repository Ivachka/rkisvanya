const swiper = new Swiper(".swiper", {
    effect: "fade",
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    autoplay: {
      delay: 2700,
      disable0nInteraction: false,
    },
  });