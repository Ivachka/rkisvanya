<!doctype html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>ccode</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
	<div class="wrapper">
		<header>
            <nav class="top-menu">
				<div>
					<a href="#"><img class="logo" src="img/logo.png"></a>
				</div>
				<div>
					<ul class="TopMenuButtonBox">
						<li>
							<div class="MenuButton">
								<a href="index.html">Главная</a>
							</div>	
						</li>
						<li>
							<div class="MenuButton">
								<a href="#">Услуги</a>
							</div>	
						</li>
						<li>
							<div class="MenuButton">
								<a href="map.html">Карта</a>
							</div>	
						</li>
						<li>
							<div class="MenuButton">
								<a href="profil.php">Личный кабинет</a>
							</div>	
						</li>
					</ul>
				</div>
				<div>
					<input type="hidden" class="hidden">
				</div>
            </nav>
        </header>
		
		<div class="content">
			<div class="box-serv" id="search_res"> 
				<form class="search_punel" action="index2.php" method="get">
					<input type="search" name="search_text">
					<input class="search-button" type="submit" name="submit" value="Найти`">
				</form>
				<?php
			$mysqli = new mysqli("localhost","root","","apteka",3306);
			if (isset($_GET['submit'])){
					$search_res=$_GET['search_text'];
					$query = 'select * from katalog where type like "%'.$search_res.'%" or text like "%'.$search_res.'%"';
					$result = mysqli_query($mysqli, $query);
					echo '<div class="box-serv"><h2></h2><br>';
					while($n = mysqli_fetch_assoc($result)){
						echo '<div class="teh-serv"><img class="teh-img" src="img/'.$n['img'].'"><p class="teh-text">'.$n['name'].'</p><p class="teh-text">'.$n['price'].'</p><button class="serv-button">Выбрать</button></div>';
					}
					echo '</div>';
				}
				else{
					$query = 'select * from katalog';
					$result = mysqli_query($mysqli, $query);
					echo '<div class="box-serv"><h2></h2><br>';
					while($n = mysqli_fetch_assoc($result)){
						echo '<div class="teh-serv"><img class="teh-img" src="img/'.$n['img'].'"><p class="teh-text">'.$n['name'].'</p><p class="teh-text">'.$n['price'].'</p><button class="serv-button">Выбрать</button></div>';
					}
					echo '</div>';	
				}
				?>
			</div>
		</div>
	
	</div>
	<script src="#"></script>
</body>
</html>