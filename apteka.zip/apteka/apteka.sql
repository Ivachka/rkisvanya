-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 17 2024 г., 19:39
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `apteka`
--

-- --------------------------------------------------------

--
-- Структура таблицы `katalog`
--

CREATE TABLE `katalog` (
  `img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL,
  `button` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL,
  `id_kategoria` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `katalog`
--

INSERT INTO `katalog` (`img`, `name`, `price`, `button`, `id`, `id_kategoria`) VALUES
('prostuda1.jpg', 'Максилак', 299, 'подробнее', 1, 'prostuda'),
('prostuda2.jpg', 'Имудон', 266, 'подробнее', 2, 'prostuda'),
('prostuda3.jpg', 'Фамвиталь', 560, 'подробнее', 3, 'prostuda'),
('prostuda4.jpg', 'Необутин', 566, 'подробнее', 4, 'prostuda'),
('prostuda5.jpg', 'Аквамарис', 777, 'подробнее', 5, 'prostuda'),
('prostuda6.jpg', 'Гастробене', 990, 'подробнее', 6, 'prostuda'),
('gastrit1.jpg', 'Контур ТС', 577, 'подробнее', 7, 'gastrit'),
('gastrit2.jpg', 'Риниколд', 790, 'подробнее', 8, 'gastrit'),
('gastrit3.jpg', 'Аквамарис', 380, 'подробнее', 9, 'gastrit'),
('gastrit4.jpg', 'Гептрал', 560, 'подробнее', 10, 'gastrit'),
('gastrit5.jpg', 'Анвимакс', 460, 'подробнее', 11, 'gastrit'),
('gastrit6.jpg', 'Холистал', 790, 'подробнее', 12, 'gastrit');

-- --------------------------------------------------------

--
-- Структура таблицы `registr`
--

CREATE TABLE `registr` (
  `id` int NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parol` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `registr`
--

INSERT INTO `registr` (`id`, `number`, `parol`) VALUES
(1, '+79138136329', '$2y$10$3iEGmTMia6tS0jiWq85V5.kKa5kggefg7xhfLV9Nx/QOEKU25QepS'),
(2, '+79138136327', '$2y$10$H329NXwRAxuoiS5fa1DGx.K4aGGCqSvi2Gsa9c61wUHr82/sZkHwG'),
(3, '+79138136321', '$2y$10$7DXdcTcBUD.VHzCviCe9GunRjMkzLIQl1e5LEcNGmv/Ty95cbkAIW'),
(4, '+79138136322', '$2y$10$h8AGj1BcxOmZ6EdsAN5ljuqf12zZbFa6QbzMKdNcEDAd7jlcEwWPC'),
(5, '89138909090', '$2y$10$M87iHGqQwdqy58u4EXdGLe55UO8XzBaKcVX9lXBAJhl95gusQvVte'),
(6, '89138136329', '$2y$10$Zi76Ztg/pG0jG8mmGA6lOu6gmurY0NkBtbZWLWWn21LX1esBsK0Gm'),
(7, '89138136444', '$2y$10$kdhVwy54mamKTiOfS8Z/c.eTFx/mywaLRC40dU9d0tFnOfL.vOCtG');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `katalog`
--
ALTER TABLE `katalog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `registr`
--
ALTER TABLE `registr`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `katalog`
--
ALTER TABLE `katalog`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `registr`
--
ALTER TABLE `registr`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
