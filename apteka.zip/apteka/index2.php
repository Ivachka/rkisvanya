<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Аптека</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=El+Messiri:wght@400;700&family=Inter:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style2.css">

</head>
<body>
<header class="header">
            <div class="container">
                <div class="header__iner">
                    <a href="index.html" class="logo">
                        <img class="logo__img" src="img/logo.png" href="index.html" alt="" width="150px">
                    </a>
                    <nav class="menu">
                        <ul class="menu__list">
                            <li class="menu__list-item">
                                <a href="index.html" class="menu__list-link">Главная</a>
                            </li>
                            <li class="menu__list-item">
                                <a href="index2.php" class="menu__list-link">Каталог</a>
                            </li>
                            <li class="menu__list-item">
                                <a href="index3.html" class="menu__list-link">Личный кабинет</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
        <div class="search_res"> 
                        <form action="index2.php" method="get">
                            <input class="input_form" type="search" name="search_text">
                            <input class="search_button" type="submit" name="submit" value="Найти">
                        </form>
                       
                    </div>
    <?php
			$mysqli = new mysqli("localhost","root","","apteka",3306);
            if (isset($_GET['submit']) && isset($_GET['search_text'])){
                            $search_res=$_GET['search_text'];
                            $query = 'select * from katalog where name like "%'.$search_res.'%" or id_kategoria like "%'.$search_res.'%"';
                            $result = mysqli_query($mysqli, $query);
                            echo '<div class="box-serv"><h2></h2><br>';
                            while($n = mysqli_fetch_assoc($result)){
                                echo '<div class="teh_serv"><p class="teh_text">'.$n['name'].'<p class="phone__list"><img class="phone__list" src="img/'.$n['img'].'"><p class="phone__list">'.'</p><p class="phone__list">'.$n['price'];
                            }
                            echo '</div>';
                        }
                        else{
                         
                            //$query = 'select * from katalog';
                            //$result = mysqli_query($mysqli, $query);
                            //echo '<div class="box-serv"><h2></h2><br>';
                            //while($n = mysqli_fetch_assoc($result)){
                            //    echo '<div class="teh-serv"><img class="teh-img" src="img/'.$n['id_telefon'].'"><p class="teh-text">'.$n['id_kategoria'].'</p><p class="teh-text">'.$n['id_price'].'</p><button class="serv-button">Выбрать</button></div>';
                            //}
                            //echo '</div>';	
                        }
                        ?>
    
    <main class="main">
      <section class="katagog">
          <div class="container">       
              <div class="katalog__title">
                  <h1 class="katalog__titlee">
                      Каталог
                  </h1>
              </div> 
          </div>
      </section>
      <section class="phone__page2">
          <div class="container">
    <?php
    $a=mysqli_connect('localhost', 'root', '', 'apteka') or die('connection error'); //устанавливаем подключение к БД
    $q="SELECT * FROM katalog where id_kategoria='prostuda'"; //создаем запрос на выборку данных
    $r=mysqli_query($a, $q) or die('error:'.mysqli_error()); //выполняем запрос, сохраняя при этом результат в переменную $r
    echo '<h2 class="color__title">От простуды</h2>
    <ul class="phone__list">';
    while($n = mysqli_fetch_array($r)){   //в цикле перебираем все записи в массиве $r, при этом каждая запись обозначена переменной $n
        //здесь в теле цикла формируем div блоки для каждой карточки: 
        // По мере необходимости вставляем полученные значения из БД, пользуясь переменными вида: $n['photo'], $n['name'] и др.
        echo '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["img"].'" width="300px">
          <h3>'.$n["name"].'</h3>
          <p>'.$n["price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["button"].'</button>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["img"].'" width="300px">
          <h3>'.$n["name"].'</h3>
          <p>'.$n["price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["button"].'</button>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["img"].'" width="300px">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["id_img"].'"width="300px" width="300px">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["id_img"].'" width="300px">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
      </li>';
            '<li class="phone__item">
          <img class="img__iphone" src="img/'.$n["id_img"].'" width="300px">
          <h3>'.$n["id_telefon"].'</h3>
          <p>'.$n["id_price"].'&#8381;</p>
          <button class="phone__btn" data-modal="myModal1">'.$n["id_button"].'</button>
      </li>';      
     }
  echo '</div>'; //закрываем div внешнего блока  
  mysqli_close($a);  //закрываем подключение с базой
  ?>
                </ul>                
            </div>     
        </section>
        <section class="phone__page2">
            <div class="container">

<?php
    $a=mysqli_connect('localhost', 'root', '', 'apteka') or die('connection error'); //устанавливаем подключение к БД
    $q="SELECT * FROM katalog where id_kategoria='gastrit'"; //создаем запрос на выборку данных
    $r=mysqli_query($a, $q) or die('error:'.mysqli_error()); //выполняем запрос, сохраняя при этом результат в переменную $r
    echo ' <h2 class="color__title watch__title">От гастрита</h2>
    <ul class="phone__list">';
    while($n = mysqli_fetch_array($r)){   //в цикле перебираем все записи в массиве $r, при этом каждая запись обозначена переменной $n
        //здесь в теле цикла формируем div блоки для каждой карточки: 
        // По мере необходимости вставляем полученные значения из БД, пользуясь переменными вида: $n['photo'], $n['name'] и др.
        echo 
              '<li class="phone__item watch__item">
                <img class="img__iphone" src="img/'.$n["img"].'" width="300px">
                <h3>'.$n["name"].'</h3>
                <p>'.$n["price"].'&#8381; </p>
                <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
              </li>';
              '<li class="phone__item watch__item">
              <img class="img__iphone" src="img/'.$n["img"].'>
              <h3>'.$n["name"].'</h3>
              <p>'.$n["price"].'&#8381; </p>
              <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
            </li>';
            '<li class="phone__item watch__item">
            <img class="img__iphone" src="img/'.$n["img"].'">
            <h3>'.$n["name"].'</h3>
            <p>'.$n["price"].'&#8381; </p>
            <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
          </li>';
          '<li class="phone__item watch__item">
          <img class="img__iphone" src="img/'.$n["img"].'">
          <h3>'.$n["name"].'</h3>
          <p>'.$n["price"].'&#8381; </p>
          <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
        </li>';
        '<li class="phone__item watch__item">
        <img class="img__iphone" src="img/'.$n ["img"].'">
        <h3>'.$n["name"].'</h3>
        <p>'.$n["price"].'&#8381; </p>
        <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
      </li>';
      '<li class="phone__item watch__item">
      <img class="img__iphone" src="img/'.$n["img"].'">
      <h3>'.$n["name"].'</h3>
      <p>'.$n["price"].'&#8381; </p>
      <button class="phone__btn" data-modal="myModal10">'.$n["button"].'</button>
    </li>';
    }
    echo '</div>'; //закрываем div внешнего блока  
    mysqli_close($a);  //закрываем подключение с базой
    ?>         
            </div>
        </section>
        <section class="contacts">
          <div class="container">
              <div class="contacts__inner">
                  <form class="contacts__form" action="#">
                      <h2 class="contacts__title">Закажи лекарства прямо сейчас</h2>
                      <input class="contacts__input" type="text" placeholder="Ваше имя">
                      <input class="contacts__input" type="tel" placeholder="Номер телефона">
                      <p>В ближайшее время наш администратор свяжется с Вами</p>
                      <button type="submit">ЗАКАЗАТЬ</button>
                  </form>
              </div>
          </div>
      </section>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer__inner">
                <a class="footer__link" href="#">Политика конфиденциальности</a>
                <a href="index.html" class="logo">
                    <img src="img/logo.png" alt="лого" height="80" class="logo__img">
                </a>
                <a href="tel:+7 913 813 63-29" class="phone">+7 913-813-63-29</a>   
            </div>
        </div>
    </footer>
</body>
</html>